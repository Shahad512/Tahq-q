<?php
$conn = mysqli_connect("localhost", "root", "", "tahq1");

	/* check connection */
	if (mysqli_connect_errno()) {
	printf("Connect failed: %s\n", mysqli_connect_error());
	exit();
}
function redirect($url){
	echo '<script language="javascript">window.location="'.$url.'";</script>';
	exit;	
}
function add_activity($conn,$title,$user_id = ""){
        if($user_id=="") $user_id = $_SESSION['user'];

    mysqli_query($conn,"insert into activity set user_id = '$user_id' , title='$title'");
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


function sendmail($to,$subject,$message){
    
    
    
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
    
        $file="";
		
		
		$mail = new PHPMailer(); 
		
		$body = $message;
		$mail->IsSMTP();                            // telling the class to use SMTP
		
		$host = 'smtp.gmail.com';

		
		
		
		
		
		
		$mail->Host       = $host;       // SMTP server
		$mail->SMTPDebug  = 0;                      // enables SMTP debug information (for testing)
		$mail->CharSet = 'UTF-8';
														// 0 default no debugging messages
														// 1 = errors and messages
														// 2 = messages only
		$mail->SMTPAuth   = true;                   // enable SMTP authentication
		//$mail->SMTPSecure = 'ssl';                // Not supported
		$mail->SMTPSecure = 'ssl';                  // Supported
		$mail->Host       = $host;       // sets the SMTP server
		$mail->Port       =  465;                   // set the SMTP port for the GMAIL server
		$mail->Username   = 'tahqqw@gmail.com'; // SMTP account username (how you login at gmail)
		$mail->Password   = html_entity_decode('tahqq2030', ENT_QUOTES, 'UTF-8');      // SMTP account password (how you login at gmail)
	 
		$mail->setFrom('tahqqw@gmail.com', 'Thaqq');
	 
		$mail->addReplyTo('tahqqw@gmail.com','Thaqq');
	 
		$mail->Subject    = $subject;
	 
		$mail->AltBody    = ""; // optional, comment out and test
	 
		$mail->msgHTML($body);
	 
		$address = $to;
		$mail->addAddress($address, "...");
		// if you have attachments
	 if($file!="") $mail->addAttachment($file);  
	   
	 
		if(!$mail->Send()) {
		 
		  return false;
		  } else {
		  return true;
		 
		
		}
	}

?>