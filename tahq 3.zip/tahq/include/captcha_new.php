<?php
session_start();
//You can customize your captcha settings here

$captcha_code = '';
$total_characters_on_image = 6;

//The characters that can be used in the CAPTCHA code.
//avoid all confusing characters and numbers (For example: l, 1 and i)
$possible_captcha_letters = 'bcdfghjkmnpqrstvwxyz23456789';
$random_captcha_dots = 50;
$random_captcha_lines = 25;

$count = 0;
while ($count < $total_characters_on_image) { 
$captcha_code .= substr(
	$possible_captcha_letters,
	mt_rand(0, strlen($possible_captcha_letters)-1),
	1);
$count++;
}
$_SESSION['captcha'] = $captcha_code;
?>
