<?php session_start(); error_reporting(0); 

if(!isset($_SESSION['admin']) && $_SESSION['admin']==""){ //redirect if already Login
	$rurl = 'index.php';
	echo '<script language="javascript">window.location="'.$rurl.'";</script>';
}
?>