<?php session_start(); error_reporting(0); 

if(!isset($_SESSION['user']) && $_SESSION['user']==""){ //redirect if already Login
	$rurl = 'Login.php';
	echo '<script language="javascript">window.location="'.$rurl.'";</script>';
}
?>