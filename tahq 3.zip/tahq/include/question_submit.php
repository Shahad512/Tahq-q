<?php
if(isset($_POST['question_add'])){
    
    $comment = $_POST['comment'];
    
    mysqli_query($conn,"insert into question set  question='$comment', user_id='$user_id'");
    	
    add_activity($conn,"Question Asked");

    $url = 'welcome.php?msg=your Question submitted successfully';
        redirect($url);	

}
?>