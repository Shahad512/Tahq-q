         		<!-- What You think Modal -->
		<div class="modal fade" id="askques" tabindex="-1" aria-hidden="true">
			<div class="modal-dialog">
                
                <form method="post">

			<div class="modal-content kbr_kbr_modales d-block">
				<div class="modal-header p-0">
					
					<button type="button" class="site_custom_close close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body text-white text-center">
					
				<h1 class="mb-4"><img src="images/comment.png" class="mr-4" width="60"/> Ask Question?</h1>
        
                 <textarea name="comment" required class="form-control w-100" placeholder="Write your Question" rows="5"></textarea>

                 
                 
          </div>

					<button type="submit" name="question_add" class="btn btn-success">Submit</button>
          
					
				</div>
				
		
				</div>
                                </form>

			</div>
		