<?php
if(isset($_POST['rate_add'])){
    
    $rate = $_POST['rate_field'];
    $comment = $_POST['comment'];
    
    mysqli_query($conn,"insert into rating set rate='$rate' , comment='$comment', user_id='$user_id'");
    
    add_activity($conn,"feedback submitted");

    	$url = 'checking.php?msg=your feedback submitted successfully';
        redirect($url);	

}
?>