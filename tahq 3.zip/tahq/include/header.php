



<!-- section-1-start! -->



<div class="kbr_header">



<div class="container">



<nav class="navbar navbar-expand-lg navbar-transparent bg-transparent py-3 px-md-0 justify-content-between">



<img src="images/logo.png" width=130 alt="">





 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">

    <span class="navbar-toggler-icon"><i class="far fa-bars h1"></i></span>

  </button>

  <div class="collapse navbar-collapse justify-content-md-end" id="navbarNav">

    <ul class="navbar-nav adl_menu_style">

	<!--<li class="nav-item active h6 font-weight-bold">

           <li class="kbr_kbr_2135"><a i class="fa-solid fa-globe  text-white " href="#" class="">Arabic</i></a></li>		   

      </li>-->

      <li class="nav-item active h6 font-weight-bold">

        <a class="nav-link text-light" href="index.php">HOME</a>

      </li>

      <li class="nav-item h6 font-weight-bold ">

        <a class="nav-link text-light" href="index.php#about">ABOUT US</a>

      </li>

      <li class="nav-item h6 font-weight-bold  ">

        <a class="nav-link text-light" href="services.php">SERVICES</a>

      </li>

	  <li class="nav-item  h6 font-weight-bold">

        <a class="nav-link text-light"  href="faq.php">FAQS</a>

      </li>

      <?php if(!isset($_SESSION['user'])){ 	?>

        <li class="nav-item  h6 font-weight-bold">

          <a class="nav-link text-light"  href="Login.php">Login</a>

        </li>        
        <?php }else{ ?>
	  
      <li class="nav-item  h6 font-weight-bold">

          <a class="nav-link text-light"  href="welcome.php"><img src="images/person_outline.png" style="width: 30px;
    position: relative;
    top: -5px;"></a>

      </li>

      <li class="nav-item  h6 font-weight-bold">

          <a class="nav-link text-light"  href="logout.php">Logout</a>

      </li>
      <?php } ?>


			

      </li>

	  

    </ul>

  </div>

</nav>





</div>

</div>