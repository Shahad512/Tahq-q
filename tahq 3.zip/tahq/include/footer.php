
<!-- section-footer-start! -->

<footer class="kbr_footer_21 pt-5">
	<div class="footer_background_121">
<div class="container">

<div class="row kb-0">
  
<div class="col-md-3 pr-0  kbr_0000">
   
<ul class=" kbr_off kbr_links_style">
	
	  <li class="pb-1"><a href="index.php">Home</a></li>
	  <li class="pb-1"><a href="index.php#about">About Us</a></li>
	  <li class="pb-1"><a href="services.php">Services</a></li>
	  
</ul>
	
</div>

<div class="col-md-4 p-0 kbr_0000">
   
<ul class=" kbr_in kbr_links_style">
	 
	   <li class="pb-1"><a href="terms.php">Team of use</a></li>
	   <li class="pb-1"><a href="faq.php">FAQ</a></li>
	   
</ul>
	 
</div>



<div class="col-md-5 kbr_0000">

	<div class="site_footer_logo row">
		<div class="col"><img src="images/vision.png"  alt=""></div>
		<div class="col"><img src="images/logo.png"  alt=""></div>
	</div>
	
		
</div>
</div>


<div class="row pt-5">

<div class="col-md-12">
  
<p class="text-center text-muted">© 2022 - زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز</p>


</div>
</div>

</div>
</div>
</div>

<!-- section-footer-end! -->



<!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="js/jquery.slim.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
	
	