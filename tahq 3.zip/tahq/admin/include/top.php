<div class="col-lg-5">

    <!--  <div class="site_search_group input-group">
        <input type="text" class="form-control" placeholder="Search" aria-describedby="button-addon2">
        <div class="input-group-append">
          <button class="btn btn-success" type="button" id="button-addon2">Search</button>
        </div>
      </div>   -->   

      </div>
      
      <div class="col-lg-3">
        <ul class="site_admin_header_navbar mb-0">
            <li>
              <div class="dropdown">
                <a class="" href="activity.php">
                  <i class="fa-solid fa-bell"></i>
                </a>
                
              </div>
            </li>
            <li>
              <div class="dropdown">
                <a class="" href="questions.php">
                <i class="fa-solid fa-envelope"></i>
                </a>
                </div>
            </li>
            <li>
              <div class="dropdown">
                <a class="" href="profile.php" >
                <i class="fa-solid fa-user"></i>
                </a>
               </div>
            </li>

        </ul>
      </div>
