
<div class="sidebar-sticky pt-3">
        <div class="site_sidebar_logo mb-4">
          <h2>TAHQ'Q</h2>
        </div>
        <ul class="nav flex-column">

          <li class="nav-item">
            <a class="nav-link active" href="index.php">
              Dashboard 
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="sbc_view.php">
              Apply SBC 
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="checking_view.php">
              Error Checking
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link" href="users.php">
              Users
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link" href="feedback.php">
              Feedback
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link" href="questions.php">
              Question
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">
              Logout
            </a>
          </li>
       <!--   <li class="nav-item">
            <a class="nav-link" href="#">
              Feedback
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">
              Permissions
            </a>
          </li>-->

        </ul>


      </div>
    