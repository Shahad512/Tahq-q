<?php require_once('../include/session_admin.php');  



require_once('../include/conn.php');  

if(isset($_GET['del']) && $_GET['del'] !=""){
    
    mysqli_query($conn,"delete from sbc where id ='".$_GET['del']."'");
    
    $url = 'sbc_view.php?msg=Deleted Successfully !';
			redirect($url);	

}
?>
<html>

<head>
<title>APPLYING THE SBC</title>
	<meta charset="utf-8">
	<script src="https://kit.fontawesome.com/fd26d16765.js" crossorigin="anonymous"></script>
	<link href="https://fonts.googleapis.com/css2?family=Economica:wght@400;700&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
		integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="style.css">

</head>

<body>
    
    
<!---->
    
    
<div class="container-fluid px-0">

  <div class="row no-gutters">
    

<div class="site_admin_sidebar col-md-3 col-lg-2">
<?php require_once('include/sidebar.php');  ?>

</div>


<div class="site_admin_content col-md-9 ml-sm-auto col-lg-10">





  <!-- section-12-start! -->



  <div class="kbr_section_12 px-4 pt-0">

  <div class="site_admin_header">

<div class="container">

  <div class="row">

  <div class="col-lg-6"><h1 class="site_page_title text-white mb-0">APPLYING THE SBC</h1></div>
  <div class="col-lg-6">
      <div class="text-right"><a href="add_sbc.php" class="btn btn-success"><i class="far fa-plus"></i> Add New</a></div>

      </div>
      
  </div>

</div>

</div>
    <div class="container">
      <div class="row py-5">
        <div class="col-md-12">
            <?php if(isset($_GET['msg']) && $_GET['msg'] != ""){ ?>
    
              <div class="alert alert-success" role="alert">
                <?=$_GET['msg'] ?>
              </div>
    
            <?php } ?>



<!---->
            	<div class="kbr_section_11">

		<section class="pt-5">

			<div class="container">

				
			<div class="row">
				<div class="col-lg-12">
                          							<form id="msform">

					<ul class="site_sbc_tabs nav nav-pills mb-5 justify-content-center" id="pills-tab" role="tablist">
						<li class="nav-item" role="presentation">
						  <a class="nav-link active" data-toggle="pill" href="#pills-sbc-1">Schematic Desgin</a>
						</li>
						<li class="nav-item" role="presentation">
						  <a class="nav-link" data-toggle="pill" href="#pills-sbc-2">Desgin Development</a>
						</li>
						<li class="nav-item" role="presentation">
						  <a class="nav-link" data-toggle="pill" href="#pills-sbc-3">Construction Documents</a>
						</li>
					</ul>
					  <div class="tab-content" id="pills-tabContent">

						<div class="tab-pane fade show active" id="pills-sbc-1" role="tabpanel">


								<!-- fieldsets -->
								<fieldset>
                                    
                                    
									<div class="form-card mb-4">
										<div class="row">
											<div class="col-lg-12">
												
                                                
                                                          <?php
                                    
                                    $query = mysqli_query($conn,"select * from sbc  order by id asc limit 5");
                                                
                                                while($row = mysqli_fetch_array($query)){
                                    
                                    ?>
                                                <div class="card position-relative kbr_services_box px-3 pr-4 py-4 mb-4">

													<div class="card-body">
						
														<div class="row">
						
															<div class="col">
						
																<h2 class="text-white"><?=$row['stage']?> <?=$row['title']?> <a href="edit_sbc.php?id=<?php echo $row['id']?>"><i class="far fa-edit" aria-hidden="true"></i></a> <a href="sbc_view.php?del=<?=$row['id']?>" onclick="return confirm('Are you Sure!')"><i class="fas fa-times" style="color:red"></i></a></h2>
						
															</div>
						

														</div>
						
														<p class="card-text adl_para_style pt-3 text-white text-justify"><?=$row['detail']?></p>
						
														<a  class="text-white"><?=$row['reference']?></a>
						
													</div>
						
												</div>	
                                                
                                                <?php } ?>
																											
											</div>
											
										</div> 
									</div> 
									
									<button type="button" name="next" class="site_action_btns next action-button float-right"><i class="fa-solid fa-chevron-right"></i></button>

								</fieldset>
								<fieldset>
									<div class="form-card mb-4">
										<div class="row">
											<div class="col-lg-12">
												     <?php
                                    
                                    $query = mysqli_query($conn,"select * from sbc  order by id asc limit 5 OFFSET 5");
                                                
                                                while($row = mysqli_fetch_array($query)){
                                    
                                    ?>
                                                <div class="card position-relative kbr_services_box px-3 pr-4 py-4 mb-4">

													<div class="card-body">
						
														<div class="row">
						
															<div class="col">
						
																<h2 class="text-white"><?=$row['stage']?> <?=$row['title']?> <a href="edit_sbc.php?id=<?php echo $row['id']?>"><i class="far fa-edit" aria-hidden="true"></i></a> <a href="sbc_view.php?del=<?=$row['id']?>" onclick="return confirm('Are you Sure!')"><i class="fas fa-times" style="color:red"></i></a></h2>
						
															</div>
						

														</div>
						
														<p class="card-text adl_para_style pt-3 text-white text-justify"><?=$row['detail']?></p>
						
														<a  class="text-white"><?=$row['reference']?></a>
						
													</div>
						
												</div>	
                                                
                                                <?php } ?>
																																				
											</div>
											
										</div> 
									</div> 
									<button type="button" class="site_action_btns action-button float-right site_active_sbc_2"  data-toggle="pill" href="#pills-sbc-2"><i class="fa-solid fa-chevron-right"></i></button>									
									<button type="button" name="previous" class="site_action_btns previous action-button-previous float-right"><i class="fa-solid fa-chevron-left"></i></button>


								</fieldset>





						</div>
						<div class="tab-pane fade" id="pills-sbc-2" role="tabpanel">
							

								<!-- fieldsets -->
								<fieldset>
									<div class="form-card mb-4">
										<div class="row">
											<div class="col-lg-12">
                                                				     <?php
                                    
                                    $query = mysqli_query($conn,"select * from sbc  order by id asc limit 5 OFFSET 10");
                                                
                                                while($row = mysqli_fetch_array($query)){
                                    
                                    ?>
                                                <div class="card position-relative kbr_services_box px-3 pr-4 py-4 mb-4">

													<div class="card-body">
						
														<div class="row">
						
															<div class="col">
						
																<h2 class="text-white"><?=$row['stage']?> <?=$row['title']?> <a href="edit_sbc.php?id=<?php echo $row['id']?>"><i class="far fa-edit" aria-hidden="true"></i></a> <a href="sbc_view.php?del=<?=$row['id']?>" onclick="return confirm('Are you Sure!')"><i class="fas fa-times" style="color:red"></i></a></h2>
						
															</div>

														</div>
						
														<p class="card-text adl_para_style pt-3 text-white text-justify"><?=$row['detail']?></p>
						
														<a  class="text-white"><?=$row['reference']?></a>
						
													</div>
						
												</div>	
                                                
                                                <?php } ?>
																																				
																															
											</div>
											
										</div> 
									</div> 
									
									<button type="button" name="next" class="site_action_btns next action-button float-right"><i class="fa-solid fa-chevron-right"></i></button>
                                    
									<button type="button" name="previous" class="site_action_btns previous action-button-previous float-right"><i class="fa-solid fa-chevron-left"></i></button>

								</fieldset>
								<fieldset>
									<div class="form-card mb-4">
										<div class="row">
											<div class="col-lg-12">
																     <?php
                                    
                                    $query = mysqli_query($conn,"select * from sbc  order by id asc limit 5 OFFSET 15");
                                                
                                                while($row = mysqli_fetch_array($query)){
                                    
                                    ?>
                                                <div class="card position-relative kbr_services_box px-3 pr-4 py-4 mb-4">

													<div class="card-body">
						
														<div class="row">
						
															<div class="col">
						
																<h2 class="text-white"><?=$row['stage']?> <?=$row['title']?> <a href="edit_sbc.php?id=<?php echo $row['id']?>"><i class="far fa-edit" aria-hidden="true"></i></a> <a href="sbc_view.php?del=<?=$row['id']?>" onclick="return confirm('Are you Sure!')"><i class="fas fa-times" style="color:red"></i></a></h2>
						
															</div>
						

														</div>
						
														<p class="card-text adl_para_style pt-3 text-white text-justify"><?=$row['detail']?></p>
						
														<a  class="text-white"><?=$row['reference']?></a>
						
													</div>
						
												</div>	
                                                
                                                <?php } ?>
																																																											
											</div>
											
										</div> 
									</div> 
									<button type="button" class="site_action_btns action-button float-right site_active_sbc_3"  data-toggle="pill" href="#pills-sbc-3"><i class="fa-solid fa-chevron-right"></i></button>									
									<button type="button" name="previous" class="site_action_btns previous action-button-previous float-right"><i class="fa-solid fa-chevron-left"></i></button>


								</fieldset>

						</div>
						<div class="tab-pane fade" id="pills-sbc-3" role="tabpanel" >


								<!-- fieldsets -->
								<fieldset>
									<div class="form-card mb-4">
										<div class="row">
											<div class="col-lg-12">
																     <?php
                                    
                                    $query = mysqli_query($conn,"select * from sbc  order by id asc limit 5 OFFSET 20");
                                                
                                                while($row = mysqli_fetch_array($query)){
                                    
                                    ?>
                                                <div class="card position-relative kbr_services_box px-3 pr-4 py-4 mb-4">

													<div class="card-body">
						
														<div class="row">
						
															<div class="col">
						
																<h2 class="text-white"><?=$row['stage']?> <?=$row['title']?> <a href="edit_sbc.php?id=<?php echo $row['id']?>"><i class="far fa-edit" aria-hidden="true"></i></a> <a href="sbc_view.php?del=<?=$row['id']?>" onclick="return confirm('Are you Sure!')"><i class="fas fa-times" style="color:red"></i></a></h2>
						
															</div>
						

														</div>
						
														<p class="card-text adl_para_style pt-3 text-white text-justify"><?=$row['detail']?></p>
						
														<a  class="text-white"><?=$row['reference']?></a>
						
													</div>
						
												</div>	
                                                
                                                <?php } ?>
																																																											
											</div>
											
										</div> 
									</div> 
									
									<button type="button" name="next" class="site_action_btns next action-button float-right"><i class="fa-solid fa-chevron-right"></i></button>
                                    
									<button type="button" name="previous" class="site_action_btns previous action-button-previous float-right"><i class="fa-solid fa-chevron-left"></i></button>

								</fieldset>
								<fieldset>
									<div class="form-card mb-4">
										<div class="row">
											<div class="col-lg-12">
															     <?php
                                    
                                    $query = mysqli_query($conn,"select * from sbc  order by id asc limit 5 OFFSET 25");
                                                
                                                while($row = mysqli_fetch_array($query)){
                                    
                                    ?>
                                                <div class="card position-relative kbr_services_box px-3 pr-4 py-4 mb-4">

													<div class="card-body">
						
														<div class="row">
						
															<div class="col">
						
																<h2 class="text-white"><?=$row['stage']?> <?=$row['title']?> <a href="edit_sbc.php?id=<?php echo $row['id']?>"><i class="far fa-edit" aria-hidden="true"></i></a> <a href="sbc_view.php?del=<?=$row['id']?>" onclick="return confirm('Are you Sure!')"><i class="fas fa-times" style="color:red"></i></a></h2>
						
															</div>
						

														</div>
						
														<p class="card-text adl_para_style pt-3 text-white text-justify"><?=$row['detail']?></p>
						
														<a  class="text-white"><?=$row['reference']?></a>
						
													</div>
						
												</div>	
                                                
                                                <?php } ?>
																																																											
											</div>
											
										</div> 
									</div> 
									
									<button type="button" name="previous" class="site_action_btns previous action-button-previous float-right"><i class="fa-solid fa-chevron-left"></i></button>
                                    


								</fieldset>

						</div>
                          
					  </div>					

                </div></form>
			</div>


			</div>



	</div>




		<!-- Modal -->
		<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog">
			<div class="modal-content kbr_kbr_modales d-block">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel"><h3 class="kbr_modal_2323 text-center">The steps of Applying the SBC during design is completed </h3></h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body text-white text-center">
					
				<p>All the steps of applying the SBC during design is documented in the following pdf file</p>
			
					<a type="button" class="btn btn-success mb-4" target="_blank" href="sbc_pdf.php">DOWNLOAD PDF</a>
					<P>Download the steps without reference </P>
					<a type="button" class="btn btn-success mb-4" target="_blank" href="sbc_pdf_without.php">DOWNLOAD PDF</a><br>
					<button type="button" class="btn btn-success" data-dismiss="modal" >BACK</button>
				</div>
				
		
				</div>
			</div>
		</div>

            
            
        </div>
      </div>
    </div>
  </div>

</div>

</div>

</div>


    
<!----->
    

	<!-- section-2-start! -->

	<!-- section-11-start! -->

<!----hh-->
		<!-- Optional JavaScript; choose one of the two! -->

		<!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
		<script type='text/javascript' src='js/jquery.min.js'></script>		
		<!--script src="js/jquery.slim.min.js"></script-->
		<script src="js/bootstrap.bundle.min.js"></script>
		
		<script src="js/script.js"></script>
</body>

</html>