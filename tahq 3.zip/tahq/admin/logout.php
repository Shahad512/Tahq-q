<?php  session_start(); error_reporting(0); 
require_once('../include/conn.php');  
  session_destroy();
	$rurl="index.php";
	redirect($rurl);	
?>