<?php require_once('../include/session_admin.php');  



require_once('../include/conn.php');  

$admin_id = $_SESSION['admin'];

$q  = mysqli_query($conn,"select * from admin where id = '$admin_id'");

$r = mysqli_fetch_assoc($q);



$q_u = mysqli_query($conn,"select * from user");
$users = mysqli_num_rows($q_u);


$q_r = mysqli_query($conn,"select * from rating");
$ratings  = mysqli_num_rows($q_r);

$q_q = mysqli_query($conn,"select * from question");
$questions  = mysqli_num_rows($q_r);



$q_s = mysqli_query($conn,"select * from sbc");
$sbcs = mysqli_num_rows($q_s);


$q_c = mysqli_query($conn,"select * from checking");
$errors  = mysqli_num_rows($q_c);

?>
<?php
$dataPoints = array();
    
while($rr  = mysqli_fetch_array($q_r)){
    $uu = $rr['user_id'];
$q = mysqli_query($conn,"select * from user where id='$uu'");
$r = mysqli_fetch_assoc($q);
	array_push ($dataPoints, array("label"=> $r['first_name'].' '.$r['last_name'], "y"=> $rr['rate']));
	
 }
?>



<html>



<head>

<title>Dashboard</title>

  <meta charset="utf-8">

  <script src="https://kit.fontawesome.com/fd26d16765.js" crossorigin="anonymous"></script>

  <link href="https://fonts.googleapis.com/css2?family=Economica:wght@400;700&display=swap" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">



  <link rel="stylesheet" href="css/bootstrap.min.css">

  <link rel="preconnect" href="https://fonts.googleapis.com">

  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"

    integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="style.css">



</head>



<body>

<div class="container-fluid px-0">

  <div class="row no-gutters">
    

<div class="site_admin_sidebar col-md-3 col-lg-2">
<?php require_once('include/sidebar.php');  ?>

</div>


<div class="site_admin_content col-md-9 ml-sm-auto col-lg-10">

  <!-- section-2-start! -->



  <div class="kbr_section_12  px-4 pt-0" style="height:100vh">

  <div class="site_admin_header mb-5">

    <div class="container">

      <div class="row">

      <div class="col-lg-4"><h1 class="site_page_title text-white mb-0">Dashboard</h1></div>
<?php require_once("include/top.php"); ?>
      </div>

    </div>

  </div>

    <div class="container">
      <div class="row">
        
        <div class="col-md-3 m">
            <a href="feedback.php" class="card_link">
          <div class="site_admin_card card">
            <div class="card-body">
              <div class="row no-gutters">
                <div class="col-md-9">
                  <h1><?=$questions?></h1>
                  <h4>Questions</h4>
                </div>
                <div class="col-md-3">
                  <div class="site_admin_card_icon"><i class="far fa-comment"></i></div>
                </div>
              </div>
            </div>
            </div></a>
        </div>

        <div class="col-md-3 m">
                        <a href="sbc_view.php" class="card_link">

          <div class="site_admin_card card">
            <div class="card-body">
              <div class="row no-gutters">
                <div class="col-md-9">
                  <h1><?=$sbcs?></h1>
                  <h4>Applying SBC</h4>
                </div>
                <div class="col-md-3">
                  <div class="site_admin_card_icon"><i class="far fa-cogs"></i></div>
                </div>
              </div>
            </div>
                            </div> </a>      
        </div>    
        <div class="col-md-3 m">
                        <a href="checking_view.php" class="card_link">

          <div class="site_admin_card card">
            <div class="card-body">
              <div class="row no-gutters">
                <div class="col-md-9">
                  <h1><?=$errors?></h1>
                  <h4>Error SBC</h4>
                </div>
                <div class="col-md-3">
                  <div class="site_admin_card_icon"><i class="far fa-cogs"></i></div>
                </div>
              </div>
            </div>
                            </div>  </a>     
        </div>    
        
        <div class="col-md-3 m">
                        <a href="users.php" class="card_link">

          <div class="site_admin_card card">
            <div class="card-body">
              <div class="row no-gutters">
                <div class="col-md-9">
                  <h1><?=$users?></h1>
                  <h4>User Registration</h4>
                </div>
                <div class="col-md-3">
                  <div class="site_admin_card_icon"><i class="far fa-user-check"></i></div>
                </div>
              </div>
            </div>
                            </div>   </a>    
        </div>           
        

        </div>
        
        <div class="row" style="margin-top:30px;">
                    <div class="col-md-12">

            <div id="chartContainer" style="height: 370px; width: 100%;"></div>
            </div>
 </div>
        </div>
        </div>

  </div>



  <!-- section-2-end! -->



  <!-- section-12-start! -->





</div>

</div>

</div>






<!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="js/jquery.slim.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
<style>
    .site_admin_card_icon{
            font-size: 30px !important;

    }    
    h4{
            font-size: 16px !important;

    }
    .site_admin_card{
        min-height: 145px !important;
    }
    .card_link{
        color: black !important;
        text-decoration: none !important;
    }
    
    </style>
    <script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	//theme: "light2",
	title:{
		text: "Feedback"
	},
	axisX:{
		crosshair: {
			enabled: true,
			snapToDataPoint: true
		}
	},
	axisY:{
		title: "Rating",
		includeZero: true,
		crosshair: {
			enabled: true,
			snapToDataPoint: true
		}
	},
	toolTip:{
		enabled: false
	},
	data: [{
		type: "area",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>

</body>


</html>