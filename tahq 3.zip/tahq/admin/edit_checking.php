<?php require_once('../include/session_admin.php');  



require_once('../include/conn.php');  



$id = $_GET['id'];
	


if(isset($_POST['edit_checking'])){ //

	
	if($_POST['question']!="" &&  $_POST['result']!=""   && $_POST['category']!="" && $_POST['category2']!="")  {
		
$id = $_POST['id'];

$question  = $_POST['question'];

    if(isset($_POST['q_type'])){
            $q_type = $_POST['q_type'];
    }else{
        $q_type = "";
    }
        
        
    if(isset($_POST['compare'])){
        $compare = $_POST['compare'];

    }else{
        $compare = '';
    }
        
        if(isset($_POST['result'])){
            
            $result  = $_POST['result'];

        }else{
            
            $result =  '';
            
        }
        
        if(isset($_POST['type_compare'])){
            
            $type_compare  = $_POST['type_compare'];

        }else{
            
            $type_compare = '';
            
        }
        
$category  = $_POST['category'];
$category2 = $_POST['category2'];
            
                
   
        mysqli_query($conn,"Update  checking SET question='$question' ,category='$category', category2 ='$category2' , q_type = '$q_type' where id='$id'");
       
        
      $q=  mysqli_query($conn,"select * from checking_answer where question_id ='$id'");
        
        if(mysqli_num_rows($q)>0){
            
        mysqli_query($conn,"update checking_answer SET result='$result', compare='$compare' , type_compare ='$type_compare' where question_id ='$id'");
            
        }else{
        
        mysqli_query($conn,"insert INTO  checking_answer SET result='$result', compare='$compare' , type_compare ='$type_compare', question_id ='$id'");
        }
            			
			$url = 'edit_checking.php?msg=Updated Successfully !&id='.$id;
			redirect($url);	
		}
	
} 


$q = mysqli_query($conn,"select * from checking where id='$id'");
$r = mysqli_fetch_assoc($q);



$q2 = mysqli_query($conn,"select * from checking_answer where question_id='$id'");
$a = mysqli_fetch_assoc($q2);

$question  = $r['question'];
$q_type = $r['q_type'];
$result  = $a['result'];
$compare = $a['compare'];
$category  = $r['category'];
$category2 = $r['category2'];
$type_compare  = $a['type_compare'];
$cr = $a['cr'];
?>
 
<html>
 
<head>
<title>Edit Error Checking</title>
<meta charset="utf-8">
<script src="https://kit.fontawesome.com/fd26d16765.js" crossorigin="anonymous"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Economica:wght@400;700&display=swap" rel="stylesheet">	
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.min.css"><link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com"  crossorigin>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="style.css">

</head>

<body>
    
    <div class="container-fluid px-0">

  <div class="row no-gutters">
    

<div class="site_admin_sidebar col-md-3 col-lg-2">
<?php require_once('include/sidebar.php');  ?>

</div>


<div class="site_admin_content col-md-9 ml-sm-auto col-lg-10">





  <!-- section-12-start! -->



  <div class="kbr_section_12 px-md-4 pt-0">
  <div class="site_admin_header">

    <div class="container">

      <div class="row">

      <div class="col-lg-4"><h1 class="site_page_title text-white mb-0"><i class="far fa-edit"></i> EDIT ERROR CHECKING</h1></div>
      <?php require_once("include/top.php"); ?>

      </div>

    </div>

  </div>    
    <div class="container">
      <div class="row py-5">
        <div class="col-md-12">
            <?php if(isset($_GET['msg']) && $_GET['msg'] != ""){ ?>
    
              <div class="alert alert-success" role="alert">
                <?=$_GET['msg'] ?>
              </div>
    
            <?php } ?>

<form method="post">

    <?php if(isset($_GET['success']) && $_GET['success'] != ""){ ?>
    
<div class="alert alert-success" role="alert">
  <?=$_GET['success'] ?>
</div>
    
    <?php } ?>

    
    
<div class="kbr_formes-1">
<input class="form-control kbreses-20  mt-4" type="text" placeholder="Question" name="question" id="question" required value="<?=$question?>">
<input class="form-control kbreses-20 mt-4" type="text" placeholder="Answer" name="result" id="result" required value="<?=$result?>">
<input class="form-control kbreses-20 mt-4" type="text" placeholder="Compare" name="compare" id="compare" required value="<?=$compare?>">
  
    <select name="type_compare" class="form-control kbreses-20 mt-4" required>
        <option>Please Select Compare type</option>
        <option value="less" <?php if($type_compare=='less') echo "selected"?>>Less</option>
        <option value="grater" <?php if($type_compare=='grater') echo "selected"?>>Greator</option>
        <option value="YN" <?php if($type_compare=='YN') echo "selected"?>>Yes/No</option>
        <option value="between" <?php if($type_compare=='between') echo "selected"?>>Between</option>


    </select>
    
    
    <select name="q_type" class="form-control kbreses-20 mt-4" required >
        <option>Please Select Question type</option>
        <option value="radio" <?php if($q_type=='radio') echo "selected"?>>Radio</option>
        <option value="number" <?php if($q_type=='number') echo "selected"?>>Number/Float</option>
        <option value="text" <?php if($q_type=='text') echo "selected"?>>Text</option>


    </select>
    
    
    <select name="category" id="category" class="form-control kbreses-20 mt-4" required onchange="return sub_category();">
        
        <option>Please select Category</option>
        <?php $c_q = mysqli_query($conn,"select * from error_category order by id asc");
       while($c_r = mysqli_fetch_array($c_q)) { ?>
        <option value="<?=$c_r['id']?>" <?php if($category==$c_r['id']) echo 'selected'?>><?=$c_r['name']?></option>
        <?php } ?>
    
    </select>
    
    
    <select name="category2" id="category2" class="form-control kbreses-20 mt-4" required>
        
        <option>Please select Category</option>
        <?php $c2_q = mysqli_query($conn,"select * from error_sub_category order by id asc");
       while($c2_r = mysqli_fetch_array($c2_q)) { ?>
        <option value="<?=$c2_r['sort']?>" <?php if($category==$c2_r['parent_id'] && $category2==$c2_r['sort'] ) echo 'selected'?> ><?=$c2_r['name']?></option>
        <?php } ?>
    
    </select>
    
    
<input type="hidden" name="id" value="<?=$id?>">
 <button style="border:none;" type="submit" class="bttun_kbr-77766" name="edit_checking">Update</button>

</div>
    </form>        </div>
      </div>
    </div>
  </div>

</div>

</div>

</div>



<!-- section-footer-end! -->
<!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="js/jquery.slim.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
    
    <script>
    
        
        function sub_category(){
            var category_id  =  $("#category").val();
            var subcategory_id  =  $("#category2").val();
            
            $.post( "ajax.php", { category_id: category_id, subcategory_id: subcategory_id })
            .done(function( data ) {
                $("#category2").html(data);
            });

        }
    </script>
</body>
</html>