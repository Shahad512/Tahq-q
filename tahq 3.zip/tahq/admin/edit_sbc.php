<?php require_once('../include/session_admin.php');  



require_once('../include/conn.php');  



		


if(isset($_POST['edit_sbc'])){ //

	
	if($_POST['stage']!="" &&  $_POST['title']!=""  && $_POST['detail']!=""  && $_POST['reference']!="" && $_POST['category']!="")  {
		
$id = $_POST['id'];
$stage  = $_POST['stage'];
$reference = $_POST['reference'];
$title  = $_POST['title'];
$detail = $_POST['detail'];
$category = $_POST['category'];

            
                
                
		  mysqli_query($conn,"Update  sbc SET stage='$stage' ,reference='$reference', title ='$title', detail ='$detail' , category = '$category' where id='$id'");
            
            			
			$url = 'edit_sbc.php?msg=Updated Successfully !&id='.$id;
			redirect($url);	
		}
	
} 
$id = $_GET['id'];
$q = mysqli_query($conn,"select * from sbc where id='$id'");
$r = mysqli_fetch_assoc($q);
$stage  = $r['stage'];
$title = $r['title'];
$detail  = $r['detail'];
$reference = $r['reference'];
$category  = $r['category'];
?>
 
<html>
 
<head>
<title>Edit SBC</title>
<meta charset="utf-8">
<script src="https://kit.fontawesome.com/fd26d16765.js" crossorigin="anonymous"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Economica:wght@400;700&display=swap" rel="stylesheet">	
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.min.css"><link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com"  crossorigin>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="style.css">

</head>

<body>
    
    
    
<div class="container-fluid px-0">

  <div class="row no-gutters">
    

<div class="site_admin_sidebar col-md-3 col-lg-2">
<?php require_once('include/sidebar.php');  ?>

</div>


<div class="site_admin_content col-md-9 ml-sm-auto col-lg-10">





  <!-- section-12-start! -->



  <div class="kbr_section_12 px-md-4 pt-0">
  <div class="site_admin_header">

    <div class="container">

      <div class="row">

      <div class="col-lg-6"><h1 class="site_page_title text-white mb-0"><i class="far fa-edit"></i> EDIT SBC</h1></div>
      <?php require_once("include/top.php"); ?>


      </div>

    </div>

  </div>    
    <div class="container">
      <div class="row py-5">
        <div class="col-md-12">
            <?php if(isset($_GET['msg']) && $_GET['msg'] != ""){ ?>
    
              <div class="alert alert-success" role="alert">
                <?=$_GET['msg'] ?>
              </div>
    
            <?php } ?>




    <form method="post">

       <?php if(isset($_GET['success']) && $_GET['success'] != ""){ ?>
    
<div class="alert alert-success" role="alert">
  <?=$_GET['success'] ?>
</div>
    
    <?php } ?>
 
<div class="kbr_formes-1">
<input class="form-control kbreses-20  mt-4" type="text" placeholder="Stage" name="stage" id="stage" required value="<?=$stage?>">
<input class="form-control kbreses-20 mt-4" type="text" placeholder="Title" name="title" id="title" required value="<?=$title?>">
  
    <select name="category" class="form-control kbreses-20 mt-4" required >
        <option>Please Select Category</option>
        <option value="1" <?php if($category==1) echo "selected"?>>Schematic Desgin</option>
        <option value="2" <?php if($category==2) echo "selected"?>>Desgin Development</option>
        <option value="3" <?php if($category==3) echo "selected"?>>Construction Documents</option>

    </select>
    
<input class="form-control kbreses-20 mt-4" type="text" placeholder="Reference" name="reference" id="reference" required value="<?=$reference?>">
    
    <textarea  class="form-control kbreses-20 mt-4" placeholder="Detail" name="detail" required><?=$detail?></textarea>
<input type="hidden" name="id" value="<?=$id?>">
 <button style="border:none;" type="submit" class="bttun_kbr-77766" name="edit_sbc">Update</button>

</div>
    </form>
        </div>
      </div>
    </div>
  </div>

</div>

</div>

</div>



    


<!-- section-footer-end! -->
<!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="js/jquery.slim.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>