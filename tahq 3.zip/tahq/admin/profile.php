<?php require_once('../include/session_admin.php');  



require_once('../include/conn.php');  
  $admin_id = $_SESSION['admin'];

 


		


if(isset($_POST['update_profile'])){ 

	
	if($_POST['email']!=""   && $_POST['user_name']  && $_POST['password']!=""){
		
$email  = $_POST['email'];
$user_name = $_POST['user_name'];
$password = md5($_POST['password']);
$password1 = $_POST['password'];



    
		
	 $query2  = "SELECT * FROM admin WHERE password = '$password1' and id  ='$admin_id'";	
	 $check_user2  = mysqli_query($conn,$query2);
	 

            if(mysqli_num_rows($check_user2)>0){
            
            $password = $_POST['password'];

        }
    
    
        	
	 $query  = "SELECT * FROM admin WHERE email = '$email'  and id != '$admin_id'";	
	 $check_user  = mysqli_query($conn,$query);
	 
               
    $query1  = "SELECT * FROM $admin_id WHERE user_name = '$user_name' and id != '$admin_id'";	
	 $check_user1  = mysqli_query($conn,$query1);
	
		if(mysqli_num_rows($check_user)>0){ //if email already Exist
			$url = 'profile.php?errormsg=Email already Exist';
			redirect($url);	
		}elseif(mysqli_num_rows($check_user1)>0){
			$url = 'profile.php?errormsg=Username already Exist';
			redirect($url);	
		}else{
		//insert user data in db
            
                
                
		$update_user = mysqli_query($conn,"Update admin SET user_name='$user_name', email = '$email' ,  password='$password' where id ='$admin_id'");
            
            
			
			$url = 'profile.php?msg=Profile Updated successfully';
			redirect($url);	
		}
	}else{
		$url = "profile.php?errormsg=Please Fill All fileds";
				redirect($url);
	}
}else{

    $q  = mysqli_query($conn,"select * from admin where id = '$admin_id'");

$r = mysqli_fetch_assoc($q);

    
$email  = $r['email'];
$user_name = $r['user_name'];
$password = $r['password'];

} 
?>
 
<html>
 
<head>
<title>Profile</title>
<meta charset="utf-8">
<script src="https://kit.fontawesome.com/fd26d16765.js" crossorigin="anonymous"></script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Economica:wght@400;700&display=swap" rel="stylesheet">	
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/bootstrap.min.css"><link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com"  crossorigin>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"  href="style.css">

</head>

<body>
    
    
    
<div class="container-fluid px-0">

  <div class="row no-gutters">
    

<div class="site_admin_sidebar col-md-3 col-lg-2">
<?php require_once('include/sidebar.php');  ?>

</div>


<div class="site_admin_content col-md-9 ml-sm-auto col-lg-10">





  <!-- section-12-start! -->



  <div class="kbr_section_12 px-md-4 pt-0">
  <div class="site_admin_header">

    <div class="container">

      <div class="row">

      <div class="col-lg-4"><h1 class="site_page_title text-white mb-0">PROFILE</h1></div>
      
<?php require_once("include/top.php"); ?>

      </div>

    </div>

  </div>    
    <div class="container">
      <div class="row py-5">
        <div class="col-md-12">
            <?php if(isset($_GET['msg']) && $_GET['msg'] != ""){ ?>
    
              <div class="alert alert-success" role="alert">
                <?=$_GET['msg'] ?>
              </div>
    
            <?php } ?>




    <form method="post">

       <?php if(isset($_GET['success']) && $_GET['success'] != ""){ ?>
    
<div class="alert alert-success" role="alert">
  <?=$_GET['success'] ?>
</div>
    
    <?php } ?>
 
<div class="kbr_formes-1">
<input class="form-control kbreses-20  mt-4" type="text" placeholder="Username" name="user_name" id="user_name" required value="<?=$user_name?>">
<input class="form-control kbreses-20 mt-4" type="email" placeholder="Email" name="email" id="email" required value="<?=$email?>">
    
<input class="form-control kbreses-20 mt-4" type="password" placeholder="Password" name="password" id="password" required value="<?=$password?>">
    
     <button style="border:none;" type="submit" class="bttun_kbr-77766" name="update_profile">Update</button>

</div>
    </form>
        </div>
      </div>
    </div>
  </div>

</div>

</div>

</div>



    


<!-- section-footer-end! -->
<!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="js/jquery.slim.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>