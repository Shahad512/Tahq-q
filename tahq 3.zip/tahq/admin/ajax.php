<?php require_once('../include/session_admin.php');  



require_once('../include/conn.php');  


if(isset($_POST['category_id'])){
    
     $category_id = $_POST['category_id'];
     $subcategory_id = $_POST['subcategory_id'];
    
    $q  = mysqli_query($conn,"select * from error_sub_category where parent_id='$category_id'");
    
    $sss = '';
    while($r = mysqli_fetch_array($q)){
        
       if($category_id==$r['parent_id'] && $subcategory_id==$r['sort'] ) $sss =  'selected'; else $sss = '';

        echo '<option value="'.$r['sort'].'" '.$sss.' >'.$r['name'].'</option>';
    }
    
    
}

?>