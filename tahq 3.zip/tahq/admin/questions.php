<?php require_once('../include/session_admin.php');  



require_once('../include/conn.php');  
$admin_id = $_SESSION['admin'];

$q  = mysqli_query($conn,"select * from admin where id = '$admin_id'");

$r = mysqli_fetch_assoc($q);

if(isset($_GET['del']) && $_GET['del'] !=""){
    
    mysqli_query($conn,"delete from question where id ='".$_GET['del']."'");
    
    $url = 'questions.php?msg=Deleted Successfully !';
			redirect($url);	

}

if(isset($_POST['answer_add'])){
    
    $id = $_POST['id'];
    $question = $_POST['question'];
    $email = $_POST['email'];
    $comment = $_POST['comment'];

    
    
    mysqli_query($conn,"update question set replied =1  where id= '$id'");
    mysqli_query($conn,"insert into admin_answer set answer = '$comment' ,question_id='$id'");
    
    $msg = "Q ".$question."<br>";
    $msg.= "A ".$comment."<br>";
    sendmail($email,"Answer your Question",$msg);
    $url = 'questions.php?msg=Email sent to User  Successfully !';
			redirect($url);	

    
}
?>



<html>



<head>
<title>Questions</title>


  <meta charset="utf-8">

  <script src="https://kit.fontawesome.com/fd26d16765.js" crossorigin="anonymous"></script>

  <link href="https://fonts.googleapis.com/css2?family=Economica:wght@400;700&display=swap" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">



  <link rel="stylesheet" href="css/bootstrap.min.css">

  <link rel="preconnect" href="https://fonts.googleapis.com">

  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"

    integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="style.css">



</head>



<body>

<div class="container-fluid px-0">

  <div class="row no-gutters">
    

<div class="site_admin_sidebar col-md-3 col-lg-2">
<?php require_once('include/sidebar.php');  ?>

</div>


<div class="site_admin_content col-md-9 ml-sm-auto col-lg-10">




  <!-- section-12-start! -->



  <div class="kbr_section_12 px-md-4 pt-0">
  <div class="site_admin_header">

    <div class="container">

      <div class="row">

      <div class="col-lg-4"><h1 class="site_page_title text-white mb-0">QUESTIONS</h1></div>
     <?php require_once("include/top.php"); ?>


      </div>

    </div>

  </div>    
    <div class="container">
      <div class="row py-5">
        <div class="col-md-12">
            <?php if(isset($_GET['msg']) && $_GET['msg'] != ""){ ?>
    
              <div class="alert alert-success" role="alert">
                <?=$_GET['msg'] ?>
              </div>
    
            <?php } ?>



            <table class="site_admin_table table table-striped">
                                    <thead class="table-light">
                                      <tr>
                                        <th style="" scope="col" width="">User</th>
                                        <th style="" scope="col" width="">Question</th>
                                    <th style="" scope="col" width="">Replied</th>


                                        <th style="" scope="col" width="">Date</th>

                                        <th scope="col" width="">Action</th>


                                      </tr>
                                    </thead>
                                    <tbody class="text-white">
                                      
                    <?php
                                        
                    $q = mysqli_query($conn,"select * from question order by datetime desc");
                    while($r = mysqli_fetch_array($q)){  
                        
                        $user_id = $r['user_id'];
                        $rate = $r['rate'];
                            $u_q  = mysqli_query($conn,"select * from user where id = '$user_id'");

$u_r = mysqli_fetch_assoc($u_q);
                        
                    ?>
                                        <tr>
                                        <td style="" scope="col" width=""><?=$u_r['first_name']." ".$u_r['last_name']?></td>
                                        <td style="" scope="col" width=""><?=$r['question']?></td>
                                            
                                        <td style="" scope="col" width=""><?php if($r['replied']==1){ ?>
                    <a href="#" data-toggle="modal" data-target="#ans_<?=$r['id']?>">Replied</a>
 
                   <?php }else{ ?>
                        <a href="#" data-toggle="modal" data-target="#askques_<?=$r['id']?>">Reply</a>
                    <?php }?>
                                            
                
         		<!-- What You think Modal -->
		<div class="modal fade" id="ans_<?=$r['id']?>" tabindex="-1" aria-hidden="true">
			<div class="modal-dialog">
              
                <?php 
                 $q_a = mysqli_query($conn,"select * from admin_answer where question_id='".$r['id']."'");
                $r_a = mysqli_fetch_assoc($q_a);
                ?>
                
                <div class="modal-content kbr_kbr_modales d-block">
				<div class="modal-header p-0">
					
					<button type="button" class="site_custom_close close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body text-white text-center">
					               <strong> Answer : <?=$r_a['answer']?></strong>

          </div>

		  
					
				</div>
				
		
				</div>

               
			</div>
                                        
                        
                        
         		<!-- What You think Modal -->
		<div class="modal fade" id="askques_<?=$r['id']?>" tabindex="-1" aria-hidden="true">
			<div class="modal-dialog">
                
                <form method="post">

			<div class="modal-content kbr_kbr_modales d-block">
				<div class="modal-header p-0">
					
					<button type="button" class="site_custom_close close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body text-white text-center">
					
				<h1 class="mb-4"><img src="images/comment.png" class="mr-4" width="60"/> Answer</h1>
        
                 <textarea name="comment" required class="form-control w-100" placeholder="Write your Answer" rows="5"></textarea>
                    
                    <input type="hidden" name="id" value="<?=$r['id']?>">
                    <input type="hidden" name="question" value="<?=$r['question']?>">
                    <input type="hidden" name="email" value="<?=$u_r['email']?>">

                    
 

                 
                 
          </div>

					<button type="submit" name="answer_add" class="btn btn-success">Submit</button>
          
					
				</div>
				
		
				</div>
                                </form>

			</div>
                                        
                                            
                                            </td>


                                        <td style="" scope="col" width=""><?=$r['datetime']?></td>

<td>
                                          <ul class="list-inline mb-0">
                                           
                                            <li class="list-inline-item"><a onclick="return confirm('Are you Sure!')" href="questions.php?del=<?=$r['id']?>"><i style="color:red" class="fas fa-times"></i></a></li>
                                              

    </ul>
            
</td>
                                      </tr>
                                        <?php } ?>
                                     
            
                                    </tbody>
                                  </table>            

        </div>
      </div>
    </div>
  </div>

</div>

</div>

</div>

		</div>

</body>


<!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="js/jquery.slim.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>



</html>