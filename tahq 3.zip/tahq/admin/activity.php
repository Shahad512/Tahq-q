<?php require_once('../include/session_admin.php');  



require_once('../include/conn.php');  

$admin_id = $_SESSION['admin'];

$q  = mysqli_query($conn,"select * from admin where id = '$admin_id'");

$r = mysqli_fetch_assoc($q);

if(isset($_GET['del']) && $_GET['del'] !=""){
    
    mysqli_query($conn,"delete from activity where id ='".$_GET['del']."'");
    
    $url = 'activity.php?msg=Deleted Successfully !';
			redirect($url);	

}


?>



<html>



<head>
<title>Activity</title>


  <meta charset="utf-8">

  <script src="https://kit.fontawesome.com/fd26d16765.js" crossorigin="anonymous"></script>

  <link href="https://fonts.googleapis.com/css2?family=Economica:wght@400;700&display=swap" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">



  <link rel="stylesheet" href="css/bootstrap.min.css">

  <link rel="preconnect" href="https://fonts.googleapis.com">

  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"

    integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="style.css">



</head>



<body>

<div class="container-fluid px-0">

  <div class="row no-gutters">
    

<div class="site_admin_sidebar col-md-3 col-lg-2">
<?php require_once('include/sidebar.php');  ?>

</div>


<div class="site_admin_content col-md-9 ml-sm-auto col-lg-10">




  <!-- section-12-start! -->



  <div class="kbr_section_12 px-md-4 pt-0">
  <div class="site_admin_header">

    <div class="container">

      <div class="row">

      <div class="col-lg-4"><h1 class="site_page_title text-white mb-0">ACTIVITY</h1></div>
      <?php require_once("include/top.php"); ?>


      </div>

    </div>

  </div>    
    <div class="container">
      <div class="row py-5">
        <div class="col-md-12">
            <?php if(isset($_GET['msg']) && $_GET['msg'] != ""){ ?>
    
              <div class="alert alert-success" role="alert">
                <?=$_GET['msg'] ?>
              </div>
    
            <?php } ?>



            <table class="site_admin_table table table-striped">
                                    <thead class="table-light">
                                      <tr>
                                        <th style="" scope="col" width="">User</th>
                                        <th style="" scope="col" width="">Activity</th>

                                        <th style="" scope="col" width="">Date</th>

                                        <th scope="col" width="">Action</th>


                                      </tr>
                                    </thead>
                                    <tbody class="text-white">
                                      
                    <?php
                                        
                    $q = mysqli_query($conn,"select * from activity order by datetime desc");
                    while($r = mysqli_fetch_array($q)){  
                        
                        $user_id = $r['user_id'];
                            $u_q  = mysqli_query($conn,"select * from user where id = '$user_id'");

$u_r = mysqli_fetch_assoc($u_q);
                        
                    ?>
                                        <tr>
                                        <td style="" scope="col" width=""><?=$u_r['first_name']." ".$u_r['last_name']?></td>
                                        <td style="" scope="col" width=""><?=$r['title']?></td>

                                        <td style="" scope="col" width=""><?=$r['datetime']?></td>

<td>
                                          <ul class="list-inline mb-0">
                                           
                                            <li class="list-inline-item"><a onclick="return confirm('Are you Sure!')" href="activity.php?del=<?=$r['id']?>"><i style="color:red" class="fas fa-times"></i></a></li>
                                          </ul>
            
                                        </td>
                                      </tr>
                                        <?php } ?>
                                     
            
                                    </tbody>
                                  </table>            

        </div>
      </div>
    </div>
  </div>

</div>

</div>

</div>




</body>


<!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="js/jquery.slim.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>



</html>